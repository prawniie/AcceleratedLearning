﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Module7
{
    class Rectangle : Shape
    {
        public Rectangle()
        {
            Name = "rectangle";
        }
    }
}
