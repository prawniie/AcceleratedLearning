﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Module7
{
    class Shape
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public int Radius { get; set; }

        public string Name { get; set; }
    }
}
