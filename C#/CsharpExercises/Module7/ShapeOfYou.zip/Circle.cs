﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Module7
{
    class Circle : Shape
    {

        public Circle()
        {
        Name = "circle";
        }
    }

}
